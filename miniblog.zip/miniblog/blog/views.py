from django.shortcuts import render
from django.contrib import messages
from .models import Blog
from .forms import SignUpForm,Edit_Form,MyLoginForm
from django.contrib.auth.forms import AuthenticationForm,PasswordChangeForm
from django.contrib.auth import login,logout,authenticate,update_session_auth_hash
from django.http import HttpResponseRedirect
from django.contrib.auth.models import Group



# Create your views here.
# This is  a home function
def home(request):
    fm = Blog.objects.all()
    
    return render(request ,'blog/home.html',{'data':fm})


# This is an about #################
def about(request):
    return render(request,'blog/about.html')
  
#This is signup
def signup(request):
    if request.method == 'POST':
        fm = SignUpForm(request.POST)
        if fm.is_valid():
            user=fm.save()
            group=Group.objects.get(name='Editor')
            user.groups.add(group)
            messages.success(request,'Your Account created successfully')
            fm =  SignUpForm()

    else:
         fm =  SignUpForm()
    return render(request,'blog/signup.html',{'form':fm})
#dashboard##############

def dashboard(request):
   if request.user.is_authenticated:
        fm = Blog.objects.all()
        return render(request,'blog/dashboard.html',{'data':fm})
   else:
       return HttpResponseRedirect('/login/')

    
    
    
#login##############

def login_user(request):
   if not request.user.is_authenticated:
       if request.method == 'POST':
            fm = MyLoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname=fm.cleaned_data['username']
                upass=fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Logged In Successfully')
                    return HttpResponseRedirect('/dashboard/')
       else:
        fm = MyLoginForm()
       return render(request,'blog/login.html',{'form':fm})
   else:
       return HttpResponseRedirect('/dashboard/')

                
  
            
            
        #logout##############
def logout_user(request):
        logout(request)
        return HttpResponseRedirect('/login/')


#contact##############

def contact(request):
    return render(request,'blog/contact.html')


#######deleter the post 

def del_post(request,id):
    if request.method == 'POST':
        fm = Blog.objects.get(pk=id)
        print(fm)
        fm.delete()
        return HttpResponseRedirect('/dashboard/')

# ##### Edit the Form        
def edit_form(request,id):
  if request.user.is_authenticated:
        if request.method == "POST":
            pi = Blog.objects.get(pk=id)
            fm =Edit_Form(request.POST,instance=pi)
            if fm.is_valid():
                fm.save()
                return HttpResponseRedirect('/dashboard/')
        else:
                pi = Blog.objects.get(pk=id)
                fm =Edit_Form(instance=pi)
                return render(request,'blog/update.html',{'form':fm})
  else:
      return HttpResponseRedirect('/login/')    


# ############ Add Post #############
def add_post(request):
        print("vineet")
        if request.method == 'POST':
            fm = Edit_Form(request.POST)
            if fm.is_valid():
               tl = fm.cleaned_data['title']
               ds = fm.cleaned_data['desc']
               reg = Blog(title=tl,desc=ds)
               reg.save()
               print("vineet kashyp")
               return HttpResponseRedirect('/dashboard/')
        else:
            fm = Edit_Form()
        return render(request,'blog/add.html',{'form':fm})
   

############Change Password################
def changepass(request):
   
        if request.method == 'POST':
            fm = PasswordChangeForm(user=request.user,data=request.POST)
            if fm.is_valid():
                fm.save()
                update_session_auth_hash(request,fm.user)
                return HttpResponseRedirect('/dashboard/')
        else:
            fm = PasswordChangeForm(user=request.user)
        return render(request,'blog/changepass.html',{'form':fm})
   
                





    
    

    
        
         
        
  


    
    

    

