from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Blog
from django.contrib.auth.forms import AuthenticationForm




class SignUpForm(UserCreationForm):
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Confirm Password'}))
    class Meta:
        model = User
        fields = ['username','first_name','last_name','email']
        labels ={'email':'Email'}
        widgets = {'first_name':forms.TextInput(attrs={'class':'form-control','placeholder':'First Name'}),
        'last_name':forms.TextInput(attrs={'class':'form-control','placeholder':'Last Name'}),
        'email':forms.EmailInput(attrs={'class':'form-control','placeholder':'Email'}),
        'username':forms.TextInput(attrs={'class':'form-control','placeholder':'Username'})}

class Edit_Form(forms.ModelForm):
   class Meta:
       model = Blog
       fields = ['title','desc']
       labels = {'title':'Title','desc':'Description'}
       widgets ={'title':forms.TextInput(attrs={'class':'form-control'}),
       'desc':forms.Textarea(attrs={'class':'form-control '})}
    
    
class MyLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password'}))